import { useState } from 'react';
import { motion } from 'motion/react';
import { Sprout } from 'lucide-react';
import { StarrySky } from './components/StarrySky';
import { Particles } from './components/Particles';
import { Plant, type EmotionType } from './components/Plant';
import { PlantModal } from './components/PlantModal';
import { MessageModal } from './components/MessageModal';
import { PoeticPhrase } from './components/PoeticPhrase';
import { MusicToggle } from './components/MusicToggle';

interface PlantData {
  id: number;
  emotion: EmotionType;
  message: string;
  x: number;
  y: number;
  date: Date;
}

export default function App() {
  const [plants, setPlants] = useState<PlantData[]>([]);
  const [isPlantModalOpen, setIsPlantModalOpen] = useState(false);
  const [selectedPlant, setSelectedPlant] = useState<PlantData | null>(null);

  const handlePlant = (emotion: EmotionType, message: string) => {
    const newPlant: PlantData = {
      id: Date.now(),
      emotion,
      message,
      x: Math.random() * 80 + 10, // 10% to 90% from left
      y: Math.random() * 15 + 2,   // 2% to 17% from bottom (no chão)
      date: new Date(),
    };
    setPlants([...plants, newPlant]);
  };

  const handlePlantClick = (plant: PlantData) => {
    setSelectedPlant(plant);
  };

  return (
    <div className="relative size-full overflow-hidden bg-gradient-to-b from-indigo-950 via-blue-900 to-emerald-950">
      {/* Background layers */}
      <StarrySky />
      <Particles />
      <PoeticPhrase />
      <MusicToggle />

      {/* Campo/Pradaria */}
      <div className="absolute inset-x-0 bottom-0 h-2/3 bg-gradient-to-t from-green-900 via-emerald-800 to-transparent" />

      {/* Camada de grama texturizada */}
      <div className="absolute inset-x-0 bottom-0 h-1/2 bg-gradient-to-t from-green-950 via-green-900/80 to-transparent">
        <div className="absolute inset-0 opacity-30" style={{
          backgroundImage: `repeating-linear-gradient(
            90deg,
            transparent,
            transparent 2px,
            rgba(0,0,0,0.1) 2px,
            rgba(0,0,0,0.1) 4px
          )`
        }} />
      </div>

      {/* Grama detalhada na base */}
      <div className="absolute inset-x-0 bottom-0 h-40 overflow-hidden">
        <svg className="absolute bottom-0 w-full h-48" viewBox="0 0 1200 200" preserveAspectRatio="none">
          <path
            d="M0,100 Q50,70 100,100 T200,100 T300,100 T400,100 T500,100 T600,100 T700,100 T800,100 T900,100 T1000,100 T1100,100 T1200,100 L1200,200 L0,200 Z"
            fill="rgba(22, 101, 52, 0.6)"
          />
          <path
            d="M0,130 Q40,100 80,130 T160,130 T240,130 T320,130 T400,130 T480,130 T560,130 T640,130 T720,130 T800,130 T880,130 T960,130 T1040,130 T1120,130 T1200,130 L1200,200 L0,200 Z"
            fill="rgba(20, 83, 45, 0.8)"
          />
          <path
            d="M0,160 Q30,140 60,160 T120,160 T180,160 T240,160 T300,160 T360,160 T420,160 T480,160 T540,160 T600,160 T660,160 T720,160 T780,160 T840,160 T900,160 T960,160 T1020,160 T1080,160 T1140,160 T1200,160 L1200,200 L0,200 Z"
            fill="rgba(5, 46, 22, 0.9)"
          />
        </svg>
      </div>

      {/* Névoa no chão */}
      <div className="absolute inset-x-0 bottom-0 h-32 bg-gradient-to-t from-emerald-950/40 to-transparent pointer-events-none" />

      {/* Plants */}
      {plants.map((plant) => (
        <Plant
          key={plant.id}
          emotion={plant.emotion}
          message={plant.message}
          x={plant.x}
          y={plant.y}
          onClick={() => handlePlantClick(plant)}
        />
      ))}

      {/* Main UI */}
      <div className="relative z-20 size-full flex flex-col items-center justify-center p-4">
        {plants.length === 0 && (
          <motion.div
            className="text-center mb-8"
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5 }}
          >
            <h1 className="text-4xl md:text-6xl text-amber-100 mb-4 font-light tracking-wide drop-shadow-lg">
              Jardim Digital
            </h1>
            <p className="text-purple-200 text-lg md:text-xl font-light italic">
              Um espaço para cultivar emoções
            </p>
          </motion.div>
        )}

        <motion.button
          onClick={() => setIsPlantModalOpen(true)}
          className="fixed bottom-8 left-1/2 -translate-x-1/2 px-8 py-4 bg-gradient-to-r from-emerald-700 to-teal-700 hover:from-emerald-600 hover:to-teal-600 text-white rounded-full shadow-2xl shadow-emerald-900/50 flex items-center gap-3 backdrop-blur-sm border border-emerald-400/30 transition-all"
          whileHover={{ scale: 1.05, y: -2 }}
          whileTap={{ scale: 0.95 }}
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1 }}
        >
          <Sprout size={24} />
          <span className="text-lg font-light">Plantar</span>
        </motion.button>
      </div>

      {/* Modals */}
      <PlantModal
        isOpen={isPlantModalOpen}
        onClose={() => setIsPlantModalOpen(false)}
        onPlant={handlePlant}
      />

      {selectedPlant && (
        <MessageModal
          isOpen={!!selectedPlant}
          onClose={() => setSelectedPlant(null)}
          emotion={selectedPlant.emotion}
          message={selectedPlant.message}
          date={selectedPlant.date}
        />
      )}

      {/* Subtle vignette */}
      <div className="absolute inset-0 bg-radial-gradient pointer-events-none"
           style={{ background: 'radial-gradient(circle at center, transparent 0%, rgba(0,0,0,0.4) 100%)' }} />
    </div>
  );
}