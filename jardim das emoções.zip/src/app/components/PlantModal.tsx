import { motion, AnimatePresence } from 'motion/react';
import { useState } from 'react';
import { X } from 'lucide-react';
import type { EmotionType } from './Plant';

interface PlantModalProps {
  isOpen: boolean;
  onClose: () => void;
  onPlant: (emotion: EmotionType, message: string) => void;
}

const emotions: { value: EmotionType; label: string; emoji: string }[] = [
  { value: 'esperança', label: 'Esperança', emoji: '🌟' },
  { value: 'tristeza', label: 'Tristeza', emoji: '🌿' },
  { value: 'amor', label: 'Amor', emoji: '🌸' },
  { value: 'medo', label: 'Medo', emoji: '🍄' },
  { value: 'raiva', label: 'Raiva', emoji: '🌵' },
  { value: 'paz', label: 'Paz', emoji: '🌾' },
  { value: 'saudade', label: 'Saudade', emoji: '🌙' },
  { value: 'alegria', label: 'Alegria', emoji: '🌻' },
];

export function PlantModal({ isOpen, onClose, onPlant }: PlantModalProps) {
  const [selectedEmotion, setSelectedEmotion] = useState<EmotionType>('esperança');
  const [message, setMessage] = useState('');

  const handleSubmit = () => {
    if (message.trim()) {
      onPlant(selectedEmotion, message.trim());
      setMessage('');
      onClose();
    }
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          <motion.div
            className="fixed inset-0 bg-black/60 backdrop-blur-sm z-40"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
          />
          <div className="fixed inset-0 flex items-center justify-center z-50 p-4">
            <motion.div
              className="bg-gradient-to-br from-indigo-950/95 to-purple-950/95 backdrop-blur-md rounded-3xl p-8 max-w-md w-full border border-purple-500/30 shadow-2xl"
              initial={{ scale: 0.8, opacity: 0, y: 50 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.8, opacity: 0, y: 50 }}
              transition={{ type: 'spring', damping: 20 }}
            >
              <div className="flex justify-between items-center mb-6">
                <h2 className="text-2xl text-amber-200 font-light">
                  O que você quer deixar crescer aqui?
                </h2>
                <button
                  onClick={onClose}
                  className="text-purple-300 hover:text-white transition-colors"
                >
                  <X size={24} />
                </button>
              </div>

              <div className="mb-6">
                <label className="block text-purple-200 mb-3 text-sm">
                  Escolha uma emoção
                </label>
                <div className="grid grid-cols-4 gap-2">
                  {emotions.map((emotion) => (
                    <button
                      key={emotion.value}
                      onClick={() => setSelectedEmotion(emotion.value)}
                      className={`p-3 rounded-xl transition-all ${
                        selectedEmotion === emotion.value
                          ? 'bg-purple-600/60 scale-110 shadow-lg shadow-purple-500/50'
                          : 'bg-purple-900/40 hover:bg-purple-800/50'
                      }`}
                    >
                      <div className="text-2xl mb-1">{emotion.emoji}</div>
                      <div className="text-xs text-purple-200">{emotion.label}</div>
                    </button>
                  ))}
                </div>
              </div>

              <div className="mb-6">
                <label className="block text-purple-200 mb-2 text-sm">
                  Sua mensagem
                </label>
                <textarea
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  placeholder="Escreva o que sente..."
                  className="w-full bg-purple-950/50 border border-purple-500/30 rounded-xl p-4 text-purple-100 placeholder-purple-400/50 focus:outline-none focus:border-purple-400/50 focus:ring-2 focus:ring-purple-500/20 min-h-[100px] resize-none"
                  maxLength={200}
                />
                <div className="text-xs text-purple-400 mt-1 text-right">
                  {message.length}/200
                </div>
              </div>

              <button
                onClick={handleSubmit}
                disabled={!message.trim()}
                className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-500 hover:to-pink-500 disabled:from-gray-600 disabled:to-gray-700 disabled:cursor-not-allowed text-white py-3 rounded-xl transition-all transform hover:scale-105 active:scale-95 shadow-lg"
              >
                Plantar no Jardim
              </button>
            </motion.div>
          </div>
        </>
      )}
    </AnimatePresence>
  );
}
