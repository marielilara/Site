import { motion, AnimatePresence } from 'motion/react';
import { useEffect, useState } from 'react';

const phrases = [
  'Algumas raízes crescem no silêncio.',
  'Nem toda flor nasce sob o sol.',
  'O jardim se lembra.',
  'Cada pétala guarda uma memória.',
  'No escuro, a esperança brilha mais.',
  'As flores não escolhem onde nascem.',
  'O tempo cura, mas as raízes permanecem.',
  'Há beleza na melancolia.',
  'Mesmo espinhos têm propósito.',
  'O jardim respira contigo.',
];

export function PoeticPhrase() {
  const [currentPhrase, setCurrentPhrase] = useState('');
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const showPhrase = () => {
      const randomPhrase = phrases[Math.floor(Math.random() * phrases.length)];
      setCurrentPhrase(randomPhrase);
      setIsVisible(true);

      setTimeout(() => {
        setIsVisible(false);
      }, 6000);
    };

    showPhrase();
    const interval = setInterval(showPhrase, 20000);

    return () => clearInterval(interval);
  }, []);

  return (
    <AnimatePresence>
      {isVisible && (
        <motion.div
          className="fixed top-1/3 left-1/2 -translate-x-1/2 -translate-y-1/2 z-10 pointer-events-none"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -20 }}
          transition={{ duration: 1.5 }}
        >
          <div className="text-center text-amber-200/60 text-xl md:text-2xl font-light italic px-4 drop-shadow-lg">
            {currentPhrase}
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
