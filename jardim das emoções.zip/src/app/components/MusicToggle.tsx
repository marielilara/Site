import { useState, useEffect, useRef } from 'react';
import { Volume2, VolumeX } from 'lucide-react';
import { motion } from 'motion/react';

export function MusicToggle() {
  const [isPlaying, setIsPlaying] = useState(false);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  useEffect(() => {
    // Create a simple ambient sound using Web Audio API
    const AudioContext = window.AudioContext || (window as any).webkitAudioContext;

    if (AudioContext) {
      const audioContext = new AudioContext();
      const oscillator1 = audioContext.createOscillator();
      const oscillator2 = audioContext.createOscillator();
      const gainNode = audioContext.createGain();

      oscillator1.type = 'sine';
      oscillator1.frequency.setValueAtTime(220, audioContext.currentTime);
      oscillator2.type = 'sine';
      oscillator2.frequency.setValueAtTime(330, audioContext.currentTime);

      gainNode.gain.setValueAtTime(0, audioContext.currentTime);

      oscillator1.connect(gainNode);
      oscillator2.connect(gainNode);
      gainNode.connect(audioContext.destination);

      const toggleAudio = () => {
        if (isPlaying) {
          gainNode.gain.linearRampToValueAtTime(0.03, audioContext.currentTime + 0.5);
        } else {
          gainNode.gain.linearRampToValueAtTime(0, audioContext.currentTime + 0.5);
        }
      };

      if (audioContext.state === 'suspended') {
        audioContext.resume();
      }

      oscillator1.start();
      oscillator2.start();

      toggleAudio();

      return () => {
        oscillator1.stop();
        oscillator2.stop();
        audioContext.close();
      };
    }
  }, [isPlaying]);

  return (
    <motion.button
      onClick={() => setIsPlaying(!isPlaying)}
      className="fixed top-6 right-6 z-30 p-3 bg-purple-900/40 backdrop-blur-sm rounded-full border border-purple-500/30 text-purple-200 hover:text-white hover:bg-purple-800/50 transition-all"
      whileHover={{ scale: 1.1 }}
      whileTap={{ scale: 0.9 }}
      title={isPlaying ? 'Desligar música' : 'Ativar música'}
    >
      {isPlaying ? <Volume2 size={20} /> : <VolumeX size={20} />}
    </motion.button>
  );
}
