import { motion, AnimatePresence } from 'motion/react';
import { X, Calendar, Heart } from 'lucide-react';
import type { EmotionType } from './Plant';

interface MessageModalProps {
  isOpen: boolean;
  onClose: () => void;
  emotion: EmotionType;
  message: string;
  date: Date;
}

const emotionColors: Record<EmotionType, string> = {
  esperança: '#FFD700',
  tristeza: '#4A90E2',
  amor: '#FF69B4',
  medo: '#6B4C8A',
  raiva: '#DC143C',
  paz: '#98D8C8',
  saudade: '#B8A9C9',
  alegria: '#FFB347',
};

export function MessageModal({ isOpen, onClose, emotion, message, date }: MessageModalProps) {
  const formatDate = (date: Date) => {
    return new Intl.DateTimeFormat('pt-BR', {
      day: '2-digit',
      month: 'long',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    }).format(date);
  };

  const emotionColor = emotionColors[emotion];

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          <motion.div
            className="fixed inset-0 bg-black/60 backdrop-blur-sm z-40"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
          />
          <div className="fixed inset-0 flex items-center justify-center z-50 p-4">
            <motion.div
              className="bg-gradient-to-br from-amber-50 to-orange-50 rounded-2xl p-6 max-w-md w-full shadow-2xl border-4 border-amber-900/20"
              initial={{ scale: 0.5, opacity: 0, rotate: -10 }}
              animate={{ scale: 1, opacity: 1, rotate: 0 }}
              exit={{ scale: 0.5, opacity: 0, rotate: 10 }}
              transition={{ type: 'spring', damping: 15 }}
              style={{
                boxShadow: '0 20px 60px rgba(0,0,0,0.3), inset 0 1px 0 rgba(255,255,255,0.5)',
              }}
            >
              <div className="flex justify-between items-start mb-4">
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-2">
                    <Heart size={18} style={{ color: emotionColor }} fill={emotionColor} />
                    <h2 className="text-xl text-amber-900 font-semibold capitalize" style={{ color: emotionColor }}>
                      {emotion}
                    </h2>
                  </div>
                  <div className="flex items-center gap-2 text-sm text-amber-700">
                    <Calendar size={14} />
                    <span>{formatDate(date)}</span>
                  </div>
                </div>
                <button
                  onClick={onClose}
                  className="text-amber-600 hover:text-amber-900 transition-colors p-1"
                >
                  <X size={20} />
                </button>
              </div>

              <div className="bg-white/60 rounded-xl p-4 border-2 border-amber-200/50 mb-4">
                <div className="text-amber-950 text-base leading-relaxed">
                  "{message}"
                </div>
              </div>

              <div className="text-amber-600 text-xs text-center italic border-t border-amber-200 pt-3">
                Uma mensagem deixada por outro visitante do jardim
              </div>

              <div className="absolute -top-2 -right-2 w-8 h-8 bg-amber-900/10 rounded-full border-2 border-amber-900/20" />
              <div className="absolute -bottom-2 -left-2 w-6 h-6 bg-amber-900/10 rounded-full border-2 border-amber-900/20" />
            </motion.div>
          </div>
        </>
      )}
    </AnimatePresence>
  );
}
