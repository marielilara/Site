import { motion } from 'motion/react';
import { useState } from 'react';

export type EmotionType = 'esperança' | 'tristeza' | 'amor' | 'medo' | 'raiva' | 'paz' | 'saudade' | 'alegria';

interface PlantProps {
  emotion: EmotionType;
  message: string;
  x: number;
  y: number;
  onClick: () => void;
}

const plantStyles: Record<EmotionType, { color: string; emoji: string; glow: string; rare?: boolean }> = {
  esperança: { color: '#FFD700', emoji: '🌟', glow: 'drop-shadow(0 0 10px rgba(255, 215, 0, 0.8))', rare: true },
  tristeza: { color: '#4A90E2', emoji: '🌿', glow: 'drop-shadow(0 0 8px rgba(74, 144, 226, 0.6))' },
  amor: { color: '#FF69B4', emoji: '🌸', glow: 'drop-shadow(0 0 12px rgba(255, 105, 180, 0.7))' },
  medo: { color: '#6B4C8A', emoji: '🍄', glow: 'drop-shadow(0 0 6px rgba(107, 76, 138, 0.5))' },
  raiva: { color: '#DC143C', emoji: '🌵', glow: 'drop-shadow(0 0 10px rgba(220, 20, 60, 0.6))' },
  paz: { color: '#98D8C8', emoji: '🌾', glow: 'drop-shadow(0 0 8px rgba(152, 216, 200, 0.5))' },
  saudade: { color: '#B8A9C9', emoji: '🌙', glow: 'drop-shadow(0 0 10px rgba(184, 169, 201, 0.7))' },
  alegria: { color: '#FFB347', emoji: '🌻', glow: 'drop-shadow(0 0 10px rgba(255, 179, 71, 0.7))' },
};

export function Plant({ emotion, message, x, y, onClick }: PlantProps) {
  const [isHovered, setIsHovered] = useState(false);
  const style = plantStyles[emotion];

  return (
    <motion.div
      className="absolute cursor-pointer"
      style={{
        left: `${x}%`,
        bottom: `${y}%`,
        filter: style.glow,
      }}
      initial={{ scale: 0, opacity: 0 }}
      animate={{
        scale: 1,
        opacity: 1,
        rotate: [-2, 2, -2],
      }}
      transition={{
        scale: { duration: 0.8, ease: 'backOut' },
        opacity: { duration: 0.8 },
        rotate: {
          duration: 3,
          repeat: Infinity,
          ease: 'easeInOut',
        },
      }}
      whileHover={{ scale: 1.2 }}
      onClick={onClick}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      <div className="relative">
        <motion.div
          className="text-4xl md:text-5xl"
          animate={style.rare ? {
            scale: [1, 1.1, 1],
            filter: [
              'brightness(1)',
              'brightness(1.5)',
              'brightness(1)',
            ],
          } : {}}
          transition={style.rare ? {
            duration: 2,
            repeat: Infinity,
            ease: 'easeInOut',
          } : {}}
        >
          {style.emoji}
        </motion.div>

        {isHovered && (
          <motion.div
            className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 px-3 py-2 bg-black/80 text-white text-sm rounded-lg whitespace-nowrap backdrop-blur-sm"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            style={{ color: style.color }}
          >
            Clique para ler
          </motion.div>
        )}
      </div>
    </motion.div>
  );
}
