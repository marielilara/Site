import { useEffect, useState } from 'react';
import { motion } from 'motion/react';

interface Particle {
  id: number;
  x: number;
  startY: number;
  delay: number;
  duration: number;
  size: number;
}

export function Particles() {
  const [particles, setParticles] = useState<Particle[]>([]);

  useEffect(() => {
    const newParticles: Particle[] = [];
    for (let i = 0; i < 30; i++) {
      newParticles.push({
        id: i,
        x: Math.random() * 100,
        startY: 100 + Math.random() * 20,
        delay: Math.random() * 10,
        duration: Math.random() * 15 + 15,
        size: Math.random() * 4 + 2,
      });
    }
    setParticles(newParticles);
  }, []);

  return (
    <div className="absolute inset-0 overflow-hidden pointer-events-none">
      {particles.map((particle) => (
        <motion.div
          key={particle.id}
          className="absolute rounded-full"
          style={{
            left: `${particle.x}%`,
            width: `${particle.size}px`,
            height: `${particle.size}px`,
            background: 'radial-gradient(circle, rgba(255,215,0,0.8) 0%, rgba(255,215,0,0) 70%)',
            filter: 'blur(1px)',
          }}
          initial={{ y: `${particle.startY}vh`, opacity: 0 }}
          animate={{
            y: [
              `${particle.startY}vh`,
              `${particle.startY - 120}vh`,
            ],
            x: [0, Math.random() * 50 - 25],
            opacity: [0, 0.8, 0.8, 0],
          }}
          transition={{
            duration: particle.duration,
            delay: particle.delay,
            repeat: Infinity,
            ease: 'linear',
          }}
        />
      ))}
    </div>
  );
}
